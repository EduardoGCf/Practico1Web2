module.exports = (sequelize, DataTypes) => {
    const usuariohamburguesas = sequelize.define('usuariohamburguesas', {
        usuarioId: {
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
                model: 'Usuarios',
                key: 'id'
            }
        },
        hamburguesaId: {
            type: DataTypes.INTEGER,
            allowNull: false,
            references: {
                model: 'Hamburguesas',
                key: 'id'
            }
        }
    }, {
        tableName: 'usuariohamburguesas',
        timestamps: true
    });

    return usuariohamburguesas;
};
