module.exports = (sequelize, DataTypes) => {
    const Restaurante = sequelize.define('Restaurante', {
        nombre: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        direccion: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        descripcion: {
            type: DataTypes.TEXT,
            allowNull: false,
        },
        imagen: {
            type: DataTypes.STRING,
        },
    });

    Restaurante.associate = (models) => {
        Restaurante.hasMany(models.Hamburguesa, {
            foreignKey: 'RestauranteId',
            as: 'hamburguesas'
        });

        Restaurante.hasMany(models.Review, {
            foreignKey: 'RestauranteId',
            as: 'reviews',
        });

        Restaurante.belongsTo(models.Usuario, {
            foreignKey: 'UsuarioId',
            as: 'usuario',
        });
    };

    return Restaurante;
};
