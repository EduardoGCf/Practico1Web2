const { Model, DataTypes } = require('sequelize');
const sequelize = require('../config/database');

class Review extends Model {}

Review.init({
    puntuacion: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    comentario: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    UsuarioId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'usuarios',
            key: 'id'
        }
    },
    HamburguesaId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'hamburguesas',
            key: 'id'
        }
    }
}, {
    sequelize,
    modelName: 'Review',
});


module.exports = Review;
