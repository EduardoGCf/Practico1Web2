module.exports = (sequelize, DataTypes) => {
    const Hamburguesa = sequelize.define('Hamburguesa', {
        nombre: {
            type: DataTypes.STRING,
            allowNull: false
        },
        descripcion: {
            type: DataTypes.TEXT,
            allowNull: false
        },
        imagen: {
            type: DataTypes.STRING,
            allowNull: true
        },
        RestauranteId: {
            type: DataTypes.INTEGER,
            references: {
                model: 'Restaurantes',
                key: 'id'
            },
            allowNull: false
        }
    });

    Hamburguesa.associate = (models) => {
        Hamburguesa.belongsTo(models.Restaurante, {
            foreignKey: 'RestauranteId',
            as: 'restaurante'
        });
        
        Hamburguesa.hasMany(models.Review, {
            foreignKey: 'HamburguesaId',
            as : 'reviews'
        });
    };

    return Hamburguesa;
};
