const dbConfig = require("../config/db.config.js");
const Sequelize = require("sequelize");

const sequelize = new Sequelize(
    dbConfig.DB,
    dbConfig.USER,
    dbConfig.PASSWORD,
    {
        host: dbConfig.HOST,
        port: dbConfig.PORT,
        dialect: "mysql",
    }
);


const db = {};

// Importar modelos
db.Usuario = require('./usuario.model.js')(sequelize, Sequelize);
db.Restaurante = require('./restaurante.model.js')(sequelize, Sequelize);
db.Hamburguesa = require('./hamburguesa.model.js')(sequelize, Sequelize);
db.usuarioHamburguesas = require('./usuariohamburguesas.model.js')(sequelize, Sequelize);
db.Review = require('./review.model.js');

// Sincroniza los modelos con la base de datos
Object.keys(db).forEach((modelName) => {
    if (db[modelName].associate) {
        db[modelName].associate(db);
    }
});
db.Sequelize = Sequelize;
db.sequelize = sequelize;
module.exports = db;







