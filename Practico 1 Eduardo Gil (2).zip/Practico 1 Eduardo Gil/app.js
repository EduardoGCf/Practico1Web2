/* eslint-disable no-undef */
const express = require('express');
const session = require('express-session');
const path = require('path');
const multer = require('multer');
const app = express();
const routes = require('./routes'); 

// Configuración de la sesión
app.use(session({
    secret: 'tu_secreto_aqui',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } 
}));

// Configuración de almacenamiento para multer
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, path.join(__dirname, 'imagenes'));
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + path.extname(file.originalname));
    }
});
app.use('/imagenes', express.static(path.join(__dirname, 'imagenes')));
multer({ storage: storage });


// Configuración de vistas y carpeta de estáticos
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));

// Middleware para hacer disponible la variable usuarioNombre en todas las vistas
app.use((req, res, next) => {
    res.locals.usuarioNombre = req.session.usuarioNombre || null;
    next();
});

// Rutas
app.use('/', routes);

app.listen(3000, () => {
    console.log('Servidor corriendo en http://localhost:3000');
});
