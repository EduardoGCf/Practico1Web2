const express = require('express');
const router = express.Router();

const restauranteRoutes = require('./restaurante.routes.js');
const usuarioRoutes = require('./usuario.routes.js');
const reviewRoutes = require('./review.routes.js');
const hamburguesaRoutes = require('./hamburguesa.routes.js');
const restauranteController = require('../controllers/restaurante.controller.js');

// Ruta para el dashboard público
router.get('/dashboard', restauranteController.dashboard);

// Configurar las rutas
router.use('/restaurantes', restauranteRoutes);
router.use('/usuarios', usuarioRoutes);
router.use('/reviews', reviewRoutes);
router.use('/hamburguesas', hamburguesaRoutes);

// Ruta de inicio 
router.get('/', (req, res) => {
    res.redirect('/dashboard');
});

module.exports = router;
