const express = require('express');
const router = express.Router();
const usuarioController = require('../controllers/usuario.controller.js');

// Ruta para mostrar el formulario de login
router.get('/login', (req, res) => {
    res.render('login'); 
});

// Ruta para procesar el login
router.post('/login', usuarioController.login);

// Ruta para mostrar el formulario de registro
router.get('/register', (req, res) => {
    res.render('register'); 
});

// Ruta para procesar el registro
router.post('/register', usuarioController.register);

// Ruta para cerrar sesión
router.get('/logout', usuarioController.logout);

module.exports = router;
