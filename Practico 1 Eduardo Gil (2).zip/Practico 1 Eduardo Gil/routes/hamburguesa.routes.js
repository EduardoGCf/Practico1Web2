const express = require('express');
const hamburguesaController = require('../controllers/hamburguesa.controller.js');
const upload = require('../util/multer.js'); // Para manejar archivos

const router = express.Router();

// Ruta para ver el formulario de creación de una nueva hamburguesa
router.get('/:restauranteId/hamburguesas/nueva', hamburguesaController.formularioCrearHamburguesa);

// Ruta para guardar la nueva hamburguesa
router.post('/:restauranteId/hamburguesas/nueva', upload.single('imagen'), hamburguesaController.guardarHamburguesa);

// Ruta para ver el formulario de edición de una hamburguesa
router.get('/:restauranteId/hamburguesas/:hamburguesaId/editar', hamburguesaController.editarHamburguesa);

// Ruta para actualizar una hamburguesa existente
router.post('/:restauranteId/hamburguesas/:hamburguesaId', upload.single('imagen'), hamburguesaController.actualizarHamburguesa);

// Ruta para eliminar una hamburguesa
router.post('/:restauranteId/hamburguesas/:hamburguesaId/eliminar', hamburguesaController.eliminarHamburguesa);
router.post('/:hamburguesaId/comer', hamburguesaController.comerHamburguesa);

router.get('/:hamburguesaId', hamburguesaController.verHamburguesa);
module.exports = router;
