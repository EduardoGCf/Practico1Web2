const express = require('express');
const reviewController = require('../controllers/review.controller.js');

const router = express.Router();

// Ruta para crear una nueva review
router.post('/:hamburguesaId/reviews', reviewController.crearReview);

// Ruta para ver todas las reviews de una hamburguesa específica
router.get('/:hamburguesaId/reviews', reviewController.listarReviews);

module.exports = router;
