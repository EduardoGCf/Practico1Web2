const express = require('express');
const restauranteController = require('../controllers/restaurante.controller.js');
const upload = require('../config/multerConfig');

const router = express.Router();

// Rutas para restaurantes
router.post('/nuevo', upload.single('imagen'), restauranteController.guardarRestaurante);
router.post('/:id', upload.single('imagen'), restauranteController.actualizarRestaurante);



router.get('/admin/restaurantes', restauranteController.adminRestaurantes);
router.get('/admin/restaurantes/nuevo', restauranteController.crearRestaurante);
router.post('/admin/restaurantes/nuevo', upload.single('imagen'), restauranteController.guardarRestaurante);
router.get('/admin/restaurantes/:id/editar', restauranteController.editarRestaurante);
router.post('/admin/restaurantes/:id/editar', restauranteController.actualizarRestaurante);
router.post('/admin/restaurantes/:id/eliminar', restauranteController.eliminarRestaurante);
router.get('/:restauranteId/hamburguesas', restauranteController.mostrarHamburguesas);

module.exports = router;
