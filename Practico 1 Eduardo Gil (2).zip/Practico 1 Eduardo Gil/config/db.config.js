module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "root",
    DB: "burgerweek",
    PORT: 3306  
};
