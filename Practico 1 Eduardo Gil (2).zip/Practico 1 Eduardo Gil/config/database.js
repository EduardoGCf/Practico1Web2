// config/database.js
const { Sequelize } = require('sequelize');
const dbConfig = require('./db.config.js');

const sequelize = new Sequelize(dbConfig.DB, dbConfig.USER, dbConfig.PASSWORD, {
    host: dbConfig.HOST,
    dialect: 'mysql',  // Especifica 'mysql' como el dialecto
    port: dbConfig.PORT,
});

module.exports = sequelize;
