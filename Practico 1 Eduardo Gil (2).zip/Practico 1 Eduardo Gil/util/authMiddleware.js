function asegurarseAutenticado(req, res, next) {
    if (req.session && req.session.usuarioId) {
        return next();
    } else {
        res.redirect('/usuarios/login');
    }
}

module.exports = asegurarseAutenticado;
