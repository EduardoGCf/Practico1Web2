const { Usuario } = require('../models'); // Importar el modelo desde models/index.js
const bcrypt = require('bcrypt');

// Autenticar Usuario
exports.login = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Buscar usuario por email
        const usuario = await Usuario.findOne({ where: { email } });

        if (!usuario) {
            return res.status(401).render('login', { error: 'Email o contraseña incorrectos' });
        }

        // Comparar contraseña
        const passwordValida = await bcrypt.compare(password, usuario.password);

        if (!passwordValida) {
            return res.status(401).render('login', { error: 'Email o contraseña incorrectos' });
        }

        // Guardar información de la sesión (si estás usando express-session)
        req.session.usuarioId = usuario.id;
        req.session.usuarioNombre = usuario.nombre;

        // Redirigir al área protegida o al inicio
        res.redirect('/dashboard');

    } catch (error) {
        res.status(500).send({ message: error.message || "Ocurrió un error al intentar iniciar sesión." });
    }
};

// Registrar un nuevo Usuario
exports.register = async (req, res) => {
    try {
        const { nombre, email, password } = req.body;

        // Verificar si el email ya está en uso
        const usuarioExistente = await Usuario.findOne({ where: { email } });
        if (usuarioExistente) {
            return res.status(400).render('register', { error: 'El email ya está en uso.' });
        }

        // Encriptar la contraseña
        const hashedPassword = await bcrypt.hash(password, 10);

        // Crear el nuevo usuario
        const nuevoUsuario = await Usuario.create({
            nombre,
            email,
            password: hashedPassword
        });

        // Iniciar sesión automáticamente después de registrarse
        req.session.usuarioId = nuevoUsuario.id;
        req.session.usuarioNombre = nuevoUsuario.nombre;

        // Redirigir al área protegida o al inicio
        res.redirect('/dashboard');
    } catch (error) {
        res.status(500).send({ message: error.message || "Ocurrió un error al intentar registrar el usuario." });
    }
};

// Cerrar sesión
exports.logout = (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Error al cerrar sesión:', err);
            return res.status(500).send({ message: "Ocurrió un error al cerrar sesión." });
        }
        res.redirect('/dashboard'); // Redirige a la dashboard después de cerrar sesión
    });
};

// Middleware para verificar si el usuario está autenticado
exports.isAuthenticated = (req, res, next) => {
    if (req.session.usuarioId) {
        next();
    } else {
        res.redirect('/usuarios/login');
    }
};

// Middleware para pasar el nombre del usuario a todas las vistas
exports.addUserToLocals = (req, res, next) => {
    res.locals.usuarioNombre = req.session.usuarioNombre || null;
    next();
};
