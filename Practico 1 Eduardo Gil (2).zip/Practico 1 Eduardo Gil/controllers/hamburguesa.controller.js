const db = require('../models');
const Hamburguesa = db.Hamburguesa;
const Restaurante = db.Restaurante;
const UsuarioHamburguesa = db.usuarioHamburguesas;
const Review = db.Review;
const Usuario = db.Usuario;
// Mostrar formulario para crear una nueva hamburguesa
exports.formularioCrearHamburguesa = (req, res) => {
    const restauranteId = req.params.restauranteId;
    res.render('crearHamburguesa', { restauranteId });
};

exports.comerHamburguesa = async (req, res) => {
    try {
        const { hamburguesaId } = req.params;
        const usuarioId = req.session.usuarioId;

        if (!usuarioId) {
            return res.status(400).send({ message: "El usuario no está autenticado." });
        }

        await UsuarioHamburguesa.create({
            usuarioId: usuarioId,
            hamburguesaId: hamburguesaId
        });

        res.redirect(`/hamburguesas/${hamburguesaId}`);
    } catch (error) {
        console.error("Error al registrar que el usuario ha comido la hamburguesa:", error);
        res.status(500).send({ message: "Ocurrió un error al registrar la hamburguesa como comida." });
    }
};


// Guardar nueva hamburguesa
exports.guardarHamburguesa = async (req, res) => {
    try {
        const { nombre, descripcion } = req.body;
        const restauranteId = req.params.restauranteId;

        await Hamburguesa.create({
            nombre,
            descripcion,
            imagen: req.file ? req.file.filename : null,
            RestauranteId: restauranteId
        });

        res.redirect(`/restaurantes/admin/restaurantes/${restauranteId}/editar`);
    } catch (error) {
        console.error("Error al guardar la hamburguesa:", error);
        res.status(500).send({ message: "Ocurrió un error al guardar la hamburguesa." });
    }
};

exports.editarHamburguesa = async (req, res) => {
    try {
        const hamburguesaId = req.params.hamburguesaId;  // Cambiado de req.params.id a req.params.hamburguesaId
        const hamburguesa = await Hamburguesa.findByPk(hamburguesaId, {
            include: [
                {
                    model: Review,
                    as: 'reviews',
                    attributes: ['id', 'puntuacion', 'comentario', 'UsuarioId', 'HamburguesaId', 'createdAt', 'updatedAt']
                }
            ]
        });

        
        // Obtener los nombres de los usuarios que crearon las reviews
        const usuarioIds = hamburguesa.reviews.map((review) => review.UsuarioId);
        const usuarios = await Usuario.findAll({
            where: {
                id: usuarioIds,
            },
            attributes: ["id", "nombre"],
        });

        // Crear un mapa de UsuarioId a nombre
        const usuarioMap = {};
        usuarios.forEach((usuario) => {
            usuarioMap[usuario.id] = usuario.nombre;
        });

        // Agregar el nombre del usuario a cada review
        hamburguesa.reviews.forEach((review) => {
            review.dataValues.nombreUsuario = usuarioMap[review.UsuarioId];
        });


        if (!hamburguesa) {
            return res.status(404).send({ message: "Hamburguesa no encontrada." });
        }

        res.render('editarHamburguesa', { hamburguesa, reviews: hamburguesa.reviews });
    } catch (error) {
        console.error("Error al obtener la hamburguesa:", error);
        res.status(500).send({ message: "Ocurrió un error al obtener la hamburguesa." });
    }
};


// Actualizar hamburguesa existente
exports.actualizarHamburguesa = async (req, res) => {
    try {
        const { restauranteId, hamburguesaId } = req.params;
        const { nombre, descripcion } = req.body;
        const usuarioId = req.session.usuarioId; // Obtener el ID del usuario desde la sesión

        if (!usuarioId) {
            return res.status(400).send({ message: "El usuario no está autenticado." });
        }

        const hamburguesa = await Hamburguesa.findByPk(hamburguesaId);

        if (!hamburguesa) {
            return res.status(404).send({ message: "Hamburguesa no encontrada." });
        }

        const restaurante = await Restaurante.findByPk(restauranteId);

        if (!restaurante || restaurante.UsuarioId !== usuarioId) {
            return res.status(404).send({ message: "Restaurante no encontrado o no tienes permisos para editar las hamburguesas en este restaurante." });
        }

        await hamburguesa.update({
            nombre,
            descripcion,
            imagen: req.file ? req.file.filename : hamburguesa.imagen // Actualizar la imagen si se subió una nueva
        });

        res.redirect(`/restaurantes/admin/restaurantes/${restauranteId}/editar`);
    } catch (error) {
        res.status(500).send({ message: error.message || "Ocurrió un error al actualizar la hamburguesa." });
    }
};

// Eliminar una hamburguesa
exports.eliminarHamburguesa = async (req, res) => {
    try {
        const hamburguesaId = req.params.hamburguesaId;
        const hamburguesa = await Hamburguesa.findByPk(hamburguesaId);

        if (!hamburguesa) {
            return res.status(404).send({ message: "Hamburguesa no encontrada." });
        }

        await hamburguesa.destroy();
        res.redirect(`/restaurantes/admin/restaurantes//${hamburguesa.RestauranteId}/editar`);
    } catch (error) {
        console.error("Error al eliminar la hamburguesa:", error);
        res.status(500).send({ message: "Ocurrió un error al eliminar la hamburguesa." });
    }
};
// Ver una hamburguesa específica
exports.verHamburguesa = async (req, res) => {
    try {
        const hamburguesaId = req.params.hamburguesaId;
        const usuarioId = req.session.usuarioId;

        const hamburguesa = await Hamburguesa.findByPk(hamburguesaId, {
            include: [
                {
                    model: Review,
                    as: 'reviews',
                    attributes: ['id', 'puntuacion', 'comentario', 'UsuarioId', 'HamburguesaId', 'createdAt', 'updatedAt']
                }
            ]
        });

        if (!hamburguesa) {
            return res.status(404).send({ message: "Hamburguesa no encontrada." });
        }

        // Obtener los nombres de los usuarios que crearon las reviews
        const usuarioIds = hamburguesa.reviews.map((review) => review.UsuarioId);
        const usuarios = await Usuario.findAll({
            where: {
                id: usuarioIds,
            },
            attributes: ["id", "nombre"],
        });

        // Crear un mapa de UsuarioId a nombre
        const usuarioMap = {};
        usuarios.forEach((usuario) => {
            usuarioMap[usuario.id] = usuario.nombre;
        });

        // Agregar el nombre del usuario a cada review
        hamburguesa.reviews.forEach((review) => {
            review.dataValues.nombreUsuario = usuarioMap[review.UsuarioId];
        });

        // Verificar si el usuario ha comido esta hamburguesa
        let haComido = false;
        if (usuarioId) {
            const usuarioHamburguesa = await UsuarioHamburguesa.findOne({
                where: {
                    usuarioId: usuarioId,
                    hamburguesaId: hamburguesaId
                }
            });
            haComido = !!usuarioHamburguesa; // Si se encuentra un registro, haComido será true
        }

        res.render('detalleHamburguesa', { hamburguesa, reviews: hamburguesa.reviews, haComido });
    } catch (error) {
        console.error("Error al obtener la hamburguesa:", error);
        res.status(500).send({ message: "Ocurrió un error al obtener la hamburguesa." });
    }
};



// Listar todas las hamburguesas

exports.listarHamburguesas = async (req, res) => {
    try {
        const hamburguesas = await Hamburguesa.findAll({
            include: [
                {
                    model: Restaurante,
                    as: 'restaurante',
                    attributes: ['id', 'nombre']
                }
            ]
        });

        res.render('listarHamburguesas', { hamburguesas });
    } catch (error) {
        console.error("Error al obtener las hamburguesas:", error);
        res.status(500).send({ message: "Ocurrió un error al obtener las hamburguesas." });
    }
}

