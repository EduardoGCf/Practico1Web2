const db = require('../models');
const Restaurante = db.Restaurante;
const Hamburguesa = db.Hamburguesa;
// Obtener todos los restaurantes para la vista pública
exports.dashboard = async (req, res) => {
    try {
        const restaurantes = await Restaurante.findAll();
        res.render('dashboard', { restaurantes });
    } catch (error) {
        console.error("Error al obtener los restaurantes:", error);
        res.status(500).send({ message: "Ocurrió un error al obtener los restaurantes." });
    }
};


exports.editarRestaurante = async (req, res) => {
    try {
        const restauranteId = req.params.id;
        const restaurante = await Restaurante.findByPk(restauranteId, {
            include: [
                {
                    model: Hamburguesa,
                    as: 'hamburguesas'
                }
            ]
        });

        if (!restaurante) {
            return res.status(404).send({ message: "Restaurante no encontrado." });
        }

        res.render('editarRestaurantes.ejs', { restaurante, hamburguesas: restaurante.hamburguesas, reviews: restaurante.reviews });
    } catch (error) {
        res.status(500).send({ message: "Ocurrió un error al obtener los datos del restaurante.", error});
    }
};

// Mostrar todos los restaurantes en la vista de administración
exports.adminRestaurantes = async (req, res) => {
    try {
        var restaurantes = null
        if(req.session.usuarioId==1){
        restaurantes = await Restaurante.findAll();
        }else{
        restaurantes = await Restaurante.findAll({
            where: { UsuarioId: req.session.usuarioId } // Solo mostrar los restaurantes del usuario logueado
        });}
        res.render('adminRestaurantes', { restaurantes });
    } catch (error) {
        console.error('Error al obtener los restaurantes:', error);
        res.status(500).send({ message: "Ocurrió un error al obtener los restaurantes." });
    }
};

// Mostrar formulario para crear un nuevo restaurante
exports.crearRestaurante = (req, res) => {
    res.render('crearRestaurante');
};

// Guardar un nuevo restaurante
exports.guardarRestaurante = async (req, res) => {
    try {
        const { nombre, direccion, descripcion } = req.body;
        const usuarioId = req.session.usuarioId; // Obtener el ID del usuario desde la sesión

        if (!usuarioId) {
            return res.status(400).send({ message: "El usuario no está autenticado." });
        }

        await Restaurante.create({
            nombre,
            direccion,
            descripcion,
            imagen: req.file ? req.file.filename : null, // Guardar el nombre del archivo de imagen si se subió
            UsuarioId: usuarioId // Asociar el restaurante con el usuario autenticado
        });

        res.redirect('/restaurantes/admin/restaurantes');
    } catch (error) {
        console.error("Error al guardar el restaurante:", error);
        res.status(500).send({ message: "Ocurrió un error al guardar el restaurante." });
    }
};

// Actualizar un restaurante existente
exports.actualizarRestaurante = async (req, res) => {
    try {
        const { id } = req.params;
        const { nombre, direccion, descripcion } = req.body;
        const usuarioId = req.session.usuarioId; // Obtener el ID del usuario desde la sesión

        if (!usuarioId) {
            return res.status(400).send({ message: "El usuario no está autenticado." });
        }

        const restaurante = await Restaurante.findByPk(id);

        if (!restaurante ||( restaurante.UsuarioId !== usuarioId && usuarioId!=1)) {
            return res.status(404).send({ message: "Restaurante no encontrado o no tiene permisos para editarlo." });
        }

        await restaurante.update({
            nombre,
            direccion,
            descripcion,
            imagen: req.file ? req.file.filename : restaurante.imagen // Actualizar la imagen si se subió una nueva
        });

        res.redirect('/restaurantes/admin/restaurantes');
    } catch (error) {
        res.status(500).send({ message: error.message || "Ocurrió un error al actualizar el restaurante." });
    }
};


// Mostrar formulario para editar un restaurante existente
exports.editarRestaurante = async (req, res) => {
    try {
        const restauranteId = req.params.id;
        const restaurante = await db.Restaurante.findByPk(restauranteId, {
            include: [
                {
                    model: db.Hamburguesa,
                    as: 'hamburguesas'
                }
            ]
        });

        if (!restaurante) {
            return res.status(404).send({ message: "Restaurante no encontrado." });
        }

        res.render('editarRestaurante', {
            restaurante: restaurante,
            hamburguesas: restaurante.hamburguesas 
        });
    } catch (error) {
        console.error('Error al obtener el restaurante para editar:', error);
        res.status(500).send({ message: "Ocurrió un error al obtener el restaurante." });
    }
};


// Eliminar un restaurante existente
exports.eliminarRestaurante = async (req, res) => {
    try {
        const restaurante = await Restaurante.findByPk(req.params.id);
        if (!restaurante || restaurante.UsuarioId !== req.session.usuarioId) {
            return res.status(404).send({ message: "Restaurante no encontrado o no tiene permisos para eliminarlo." });
        }

        await restaurante.destroy();
        res.redirect('/restaurantes/admin/restaurantes');
    } catch (error) {
        console.error('Error al eliminar el restaurante:', error);
        res.status(500).send({ message: "Ocurrió un error al eliminar el restaurante." });
    }
};




exports.mostrarHamburguesas = async (req, res) => {
    try {
        const restaurante = await Restaurante.findByPk(req.params.restauranteId, {
    include: [{
        model: db.Hamburguesa,
        as: 'hamburguesas',
        required: false  // Esto aseguro que se haga un LEFT JOIN en lugar de un INNER JOIN
    }]
});


        if (!restaurante) {
            return res.status(404).send({ message: 'Restaurante no encontrado' });
        }

        res.render('vistaPublicaRestaurante', {
            restaurante: restaurante,
            hamburguesas: restaurante.hamburguesas
        });
    } catch (error) {
        console.error('Error al obtener las hamburguesas del restaurante:', error);
        res.status(500).send({ message: 'Error al obtener las hamburguesas del restaurante' });
    }
};

