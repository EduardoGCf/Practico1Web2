const db = require('../models');
const Review = db.Review;
const UsuarioHamburguesa = db.usuarioHamburguesas;
exports.crearReview = async (req, res) => {
    try {
        const { hamburguesaId } = req.params;
        const usuarioId = req.session.usuarioId; 
        const { puntuacion, comentario } = req.body;

        // Verifica si el usuario ha comido la hamburguesa
        const usuarioHamburguesa = await UsuarioHamburguesa.findOne({
            where: { usuarioId, hamburguesaId }
        });

        if (!usuarioHamburguesa) {
            return res.status(403).send({ message: "No puedes hacer una review porque no has comido esta hamburguesa." });
        }

        // Crear la review
        await Review.create({
            puntuacion,
            comentario,
            UsuarioId: usuarioId,
            HamburguesaId: hamburguesaId
        });

        res.redirect(`/hamburguesas/${hamburguesaId}`);
    } catch (error) {
        console.error("Error al crear la review:", error);
        res.status(500).send({ message: error.message || "Ocurrió un error al crear la review." });
    }
};


exports.listarReviews = async (req, res) => {
    try {
        const { hamburguesaId } = req.params;
        const reviews = await Review.findAll({ where: { hamburguesaId } });
        res.status(200).send(reviews);
    } catch (error) {
        res.status(500).send({ message: error.message || "Ocurrió un error al recuperar las reviews." });
    }
}

// Obtener todas las Reviews
exports.findAll = async (req, res) => {
    try {
        const reviews = await Review.findAll();
        res.status(200).send(reviews);
    } catch (error) {
        res.status(500).send({ message: error.message || "Ocurrió un error al recuperar las reviews." });
    }
};

// Obtener una Review por su ID
exports.findOne = async (req, res) => {
    try {
        const review = await Review.findByPk(req.params.id);
        if (review) {
            res.status(200).send(review);
        } else {
            res.status(404).send({ message: "Review no encontrada." });
        }
    } catch (error) {
        res.status(500).send({ message: error.message || "Ocurrió un error al recuperar la review." });
    }
};

// Actualizar una Review por su ID
exports.update = async (req, res) => {
    try {
        const [updated] = await Review.update(req.body, {
            where: { id: req.params.id }
        });
        if (updated) {
            const updatedReview = await Review.findByPk(req.params.id);
            res.status(200).send(updatedReview);
        } else {
            res.status(404).send({ message: "Review no encontrada." });
        }
    } catch (error) {
        res.status(500).send({ message: error.message || "Ocurrió un error al actualizar la review." });
    }
};

// Eliminar una Review por su ID
exports.delete = async (req, res) => {
    try {
        const deleted = await Review.destroy({
            where: { id: req.params.id }
        });
        if (deleted) {
            res.status(204).send({ message: "Review eliminada exitosamente." });
        } else {
            res.status(404).send({ message: "Review no encontrada." });
        }
    } catch (error) {
        res.status(500).send({ message: error.message || "Ocurrió un error al eliminar la review." });
    }
};
